package org.tourforge.baseline.app

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity: AudioServiceActivity() {
}
